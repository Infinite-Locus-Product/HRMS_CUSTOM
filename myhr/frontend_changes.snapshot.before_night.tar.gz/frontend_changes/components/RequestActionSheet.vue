<template>
	<div
		v-if="document?.doc"
		class="bg-white w-full flex flex-col items-center justify-center pb-5 max-h-[calc(100vh-5rem)]"
	>
		<!-- Header -->
		<div
			class="w-full flex flex-row gap-2 pt-8 pb-5 border-b border-gray-100 justify-center items-center sticky top-0 z-[100] bg-white"
		>
			<span class="text-gray-900 font-extrabold text-lg text-center">
				{{ __(document?.doctype) }}
			</span>
		</div>

		<!-- Request Summary -->
		<div class="w-full p-4 overflow-auto">
			<div class="flex flex-col items-center justify-center gap-5">
				<div
					v-for="field in fieldsWithValues"
					:key="field.fieldname"
					:class="[
						['Small Text', 'Text', 'Long Text', 'Table', 'geolocation'].includes(
							field.fieldtype
						)
							? 'flex-col'
							: 'flex-row items-center justify-between',
						'flex w-full',
					]"
				>
					<div class="text-gray-600 text-base">{{ __(field.label, null, props.modelValue?.doctype) }}</div>
					<component
						v-if="field.fieldtype === 'Table'"
						:is="field.component"
						:doc="document?.doc"
					/>
					<FormattedField
						v-else
						:value="field.value"
						:fieldtype="field.fieldtype"
						:fieldname="field.fieldname"
					/>
				</div>

				<!-- Attachments -->
				<div class="flex flex-col gap-2 w-full">
					<div
						class="text-[10px] font-black uppercase tracking-widest text-gray-400"
					>
						{{ __("Attachments") }}
					</div>
					<div
						v-if="attachedFiles?.data?.length"
						class="w-full flex flex-col gap-2"
					>
						<button
							v-for="(file, index) in attachedFiles.data"
							:key="index"
							type="button"
							@click="showFilePreview(file)"
							class="w-full rounded-xl border border-gray-100 bg-white hover:bg-blue-50/60 active:bg-blue-100/60 p-3 flex items-center gap-3 transition-colors text-left"
						>
							<div
								class="p-2 rounded-lg bg-gray-50 text-gray-600 shrink-0"
							>
								<FeatherIcon
									:name="fileIcon(file)"
									class="h-4 w-4"
								/>
							</div>
							<div class="flex-1 min-w-0">
								<div
									class="text-sm font-bold text-gray-900 truncate"
								>
									{{ file.file_name || file.name }}
								</div>
								<div
									class="text-[11px] font-bold text-gray-500 mt-0.5"
								>
									{{ __("Tap to preview") }}
								</div>
							</div>
							<FeatherIcon
								name="eye"
								class="h-4 w-4 text-gray-400 shrink-0"
							/>
						</button>
					</div>
					<div
						v-else
						class="rounded-xl border border-dashed border-gray-200 bg-gray-50/50 px-3 py-3 text-[11px] font-bold uppercase tracking-widest text-gray-400 text-center"
					>
						{{ __("No attachments") }}
					</div>
				</div>
			</div>
		</div>

		<!-- Actions -->
		<WorkflowActionSheet
			v-if="workflow?.hasWorkflow"
			:doc="document.doc"
			:workflow="workflow"
			view="actionSheet"
		/>

		<div
			v-else-if="['Open', 'Draft'].includes(document?.doc?.[approvalField]) && hasPermission('approval')"
			class="flex w-full flex-row items-center justify-between gap-3 sticky bottom-0 border-t z-[100] p-4"
		>
			<Button
				@click="openRejectDialog"
				class="w-full py-5"
				variant="subtle"
				theme="red"
			>
				<template #prefix>
					<FeatherIcon name="x" class="w-4" />
				</template>
				{{ __("Reject") }}
			</Button>

			<Button
				@click="updateDocumentStatus({ status: 'Approved' })"
				class="w-full py-5"
				variant="solid"
				theme="green"
			>
				<template #prefix>
					<FeatherIcon name="check" class="w-4" />
				</template>
				{{ __("Approve") }}
			</Button>
		</div>

		<div
			v-else-if="
				document?.doc?.docstatus === 0 &&
				(document?.doc?.doctype === 'Attendance Request' ||
					['Approved', 'Rejected'].includes(document?.doc?.[approvalField])) &&
				hasPermission('submit')
			"
			class="flex w-full flex-row items-center justify-between gap-3 sticky bottom-0 border-t z-[100] p-4"
		>
			<Button
				@click="updateDocumentStatus({ docstatus: 1 })"
				class="w-full py-5"
				variant="solid"
			>
				{{ __("Submit") }}
			</Button>
		</div>

		<div
			v-else-if="document?.doc?.docstatus === 1 && hasPermission('cancel')"
			class="flex w-full flex-row items-center justify-between gap-3 sticky bottom-0 border-t z-[100] p-4"
		>
			<Button
				@click="updateDocumentStatus({ docstatus: 2 })"
				class="w-full py-5"
				variant="subtle"
				theme="red"
			>
				<template #prefix>
					<FeatherIcon name="x" class="w-4" />
				</template>
				{{ __("Cancel") }}
			</Button>
		</div>

		<!-- Employee-side cancel for own pending request (status=Open, docstatus=0).
		     Visible only to the *filer* (owner) and only on LA / AR — Expense Claim
		     uses approval_status, not status, so the gate skips it. Approvers see
		     Approve/Reject in the branch above instead. -->
		<div
			v-else-if="canEmployeeCancel"
			class="flex w-full flex-row items-center justify-between gap-3 sticky bottom-0 border-t z-[100] p-4"
		>
			<Button
				@click="openCancelDialog"
				class="w-full py-5"
				variant="subtle"
				theme="red"
			>
				<template #prefix>
					<FeatherIcon name="x" class="w-4" />
				</template>
				{{ __("Cancel Request") }}
			</Button>
		</div>

		<!-- Reject reason capture (kept outside the v-if/v-else-if chain so it
		     doesn't break the Vue compiler's sibling check). -->
		<Dialog v-model="showRejectDialog">
			<template #body-title>
				<h2 class="text-xl font-bold">{{ __("Reject {0}", [__(props.modelValue.doctype)]) }}</h2>
			</template>
			<template #body-content>
				<div class="flex flex-col gap-3">
					<p class="text-sm text-gray-700">
						{{ __("Tell the employee why this request is being rejected. They will see this message on their request.") }}
					</p>
					<FormControl
						type="textarea"
						v-model="rejectReason"
						:placeholder="__('Reason for rejection')"
						:rows="4"
					/>
					<p v-if="rejectReasonError" class="text-sm text-red-600">{{ rejectReasonError }}</p>
				</div>
			</template>
			<template #actions>
				<div class="flex flex-row gap-3 w-full">
					<Button
						variant="outline"
						class="py-5 w-full"
						@click="showRejectDialog = false"
					>
						{{ __("Cancel") }}
					</Button>
					<Button
						variant="solid"
						theme="red"
						class="py-5 w-full"
						:loading="rejectInFlight"
						@click="confirmReject"
					>
						{{ __("Reject") }}
					</Button>
				</div>
			</template>
		</Dialog>

		<!-- Cancel reason capture -->
		<Dialog v-model="showCancelDialog">
			<template #body-title>
				<h2 class="text-xl font-bold">{{ __("Cancel {0}", [__(props.modelValue.doctype)]) }}</h2>
			</template>
			<template #body-content>
				<div class="flex flex-col gap-3">
					<p class="text-sm text-gray-700">
						{{ __("Once cancelled, this request will be removed from your approver's queue. You can file a new request afterwards if needed.") }}
					</p>
					<FormControl
						type="textarea"
						v-model="cancelReason"
						:placeholder="__('Reason for cancellation')"
						:rows="4"
					/>
					<p v-if="cancelReasonError" class="text-sm text-red-600">{{ cancelReasonError }}</p>
				</div>
			</template>
			<template #actions>
				<div class="flex flex-row gap-3 w-full">
					<Button
						variant="outline"
						class="py-5 w-full"
						@click="showCancelDialog = false"
					>
						{{ __("Keep Request") }}
					</Button>
					<Button
						variant="solid"
						theme="red"
						class="py-5 w-full"
						:loading="cancelInFlight"
						@click="confirmCancel"
					>
						{{ __("Cancel Request") }}
					</Button>
				</div>
			</template>
		</Dialog>

		<!-- File Preview Modal -->
		<ion-modal
			ref="modal"
			:is-open="showPreviewModal"
			@didDismiss="showPreviewModal = false"
		>
			<FilePreviewModal :file="selectedFile" />
		</ion-modal>

	</div>
</template>

<script setup>
import { computed, inject, ref, defineAsyncComponent, onMounted } from "vue"
import { IonModal, modalController } from "@ionic/vue"
import { useRouter } from "vue-router"
import {
	toast,
	createDocumentResource,
	createResource,
	Dialog,
	FormControl,
	Button,
	FeatherIcon,
} from "frappe-ui"

import { showErrorFromException } from "@/data/errorModal"

import FormattedField from "@/components/FormattedField.vue"
import FilePreviewModal from "@/components/FilePreviewModal.vue"
import WorkflowActionSheet from "@/components/WorkflowActionSheet.vue"

import { getCompanyCurrency } from "@/data/currencies"
import { formatCurrency } from "@/utils/formatters"

import useWorkflow from "@/composables/workflow"

const __ = inject("$translate")

const props = defineProps({
	fields: {
		type: Array,
		required: true,
	},
	showOpenForm: {
		type: Boolean,
		default: true,
	},
	modelValue: {
		type: Object,
		required: true,
	},
})
const router = useRouter()

let showPreviewModal = ref(false)
let selectedFile = ref({})
let workflow = ref(null)

// Reject-with-remarks dialog state. The Reject button on Leave Application /
// Attendance Request opens this textarea so HR has to write a reason; the
// reason is stamped into custom_rejection_reason and the LA auto-submits to
// Rejected on the same save cycle (see myhr/overrides/leave_application.py).
let showRejectDialog = ref(false)
let rejectReason = ref("")
let rejectReasonError = ref("")
let rejectInFlight = ref(false)

// Employee-side cancel-with-remarks dialog state. Mirrors the reject flow but
// goes through dedicated whitelisted endpoints (myhr.api.cancel_leave_application
// / cancel_attendance_request) which enforce the owner + status=Open gate.
let showCancelDialog = ref(false)
let cancelReason = ref("")
let cancelReasonError = ref("")
let cancelInFlight = ref(false)

const sessionEmployee = inject("$employee", null)
const sessionUser = computed(() => sessionEmployee?.data?.user_id || null)

// Cancel button is visible only when:
//   - the doctype is LA or AR (Expense Claim has its own approval_status flow)
//   - the request is still pending review (docstatus=0 for both; LA also
//     requires status=Open since LA carries its own Open/Approved/Rejected/Cancelled
//     ladder; AR has no status field and uses docstatus alone)
//   - the viewer is the original filer (owner), not the approver opening the
//     same row from Team Requests
const CANCELLABLE_DOCTYPES = ["Leave Application", "Attendance Request"]
const canEmployeeCancel = computed(() => {
	if (!CANCELLABLE_DOCTYPES.includes(props.modelValue.doctype)) return false
	const doc = document?.doc
	if (!doc) return false
	if (doc.docstatus !== 0) return false
	if (props.modelValue.doctype === "Leave Application" && doc.status !== "Open") return false
	if (!sessionUser.value) return false
	return doc.owner === sessionUser.value
})

function showFilePreview(fileObj) {
	selectedFile.value = fileObj
	showPreviewModal.value = true
}

function fileIcon(file) {
	const name = (file?.file_name || file?.name || "").toLowerCase()
	if (/\.(png|jpg|jpeg|gif|webp|svg|bmp|tiff|heic)$/i.test(name)) return "image"
	if (/\.pdf$/i.test(name)) return "file-text"
	if (/\.(doc|docx)$/i.test(name)) return "file-text"
	if (/\.(xls|xlsx|csv)$/i.test(name)) return "grid"
	if (/\.(zip|tar|gz|rar)$/i.test(name)) return "archive"
	if (/\.(mp4|mov|webm|avi)$/i.test(name)) return "video"
	if (/\.(mp3|wav|m4a|ogg)$/i.test(name)) return "music"
	return "file"
}

const document = createDocumentResource({
	doctype: props.modelValue.doctype,
	name: props.modelValue.name,
	auto: true,
	onSuccess(doc) {
		attachedFiles.reload()
	},
})

const attachedFiles = createResource({
	url: "hrms.api.get_attachments",
	params: {
		dt: props.modelValue.doctype,
		dn: props.modelValue.name,
	},
	auto: true,
})

const docPermissions = createResource({
	url: "frappe.client.get_doc_permissions",
	params: { doctype: props.modelValue.doctype, docname: props.modelValue.name },
	auto: true,
})

const permittedWriteFields = createResource({
	url: "hrms.api.get_permitted_fields_for_write",
	params: { doctype: props.modelValue.doctype },
	auto: true,
})

function hasPermission(action) {
	if (action === "approval")
		return permittedWriteFields.data?.includes(approvalField.value)
	return docPermissions.data?.permissions[action]
}

const approvalField = computed(() => {
	return props.modelValue.doctype === "Expense Claim"
		? "approval_status"
		: "status"
})

const currency = computed(() => {
	let docCurrency = document?.doc?.currency

	if (!docCurrency && document?.doc?.company) {
		docCurrency = getCompanyCurrency(document?.doc?.company)
	}
	return docCurrency
})

const fieldsWithValues = computed(() => {
	if (!document.doc) return []

	return props.fields.map((field) => {
		const raw =
			document.doc[field.fieldname] ?? props.modelValue[field.fieldname]

		if (field.fieldtype === "Currency") {
			return {
				...field,
				value: formatCurrency(raw, currency.value),
			}
		}
		if (field.fieldtype === "Table") {
			return {
				...field,
				value: raw,
				component: defineAsyncComponent(() =>
					import(`../components/${field.componentName}.vue`)
				),
			}
		}
		return { ...field, value: raw }
	})
})

const getSuccessMessage = ({ status = "", docstatus = 0 }) => {
	if (status) {
		return __("{0} successfully!", [__(status)])
	} else if (docstatus) {
		return __("Document {0} successfully!", [
			docstatus === 1 ? __("submitted") : __("cancelled"),
		])
	}
}

const getFailureMessage = ({ status = "", docstatus = 0 }) => {
	if (status) {
		return __("{0} failed!", [status === __("Approved") ? __("Approval") : __("Rejection")])
	} else if (docstatus) {
		return __('Document {0} failed!', [docstatus === 1 ? __("submission") : __("cancellation")])
	}
}

const updateDocumentStatus = ({ status = "", docstatus = 0, extraValues = {} }) => {
	let updateValues = { ...extraValues }

	if (status) updateValues[approvalField.value] = status
	if (docstatus) updateValues.docstatus = docstatus

	document.setValue.submit(
		{ ...updateValues },
		{
			onSuccess() {
				if (docstatus !== 0) modalController.dismiss()

				toast({
					title: __("Success"),
					text: getSuccessMessage({ status, docstatus }),
					icon: "check-circle",
					position: "bottom-center",
					iconClasses: "text-green-500",
				})
			},
			onError(err) {
				showErrorFromException(err, getFailureMessage({ status, docstatus }))
			},
		}
	)
}

function openRejectDialog() {
	rejectReason.value = ""
	rejectReasonError.value = ""
	showRejectDialog.value = true
}

function confirmReject() {
	const reason = (rejectReason.value || "").trim()
	if (!reason) {
		rejectReasonError.value = __("Rejection reason is required.")
		return
	}
	rejectReasonError.value = ""
	rejectInFlight.value = true
	// Leave Application uses `custom_rejection_reason` (added in setup.py).
	// Attendance Request also gets the same field for parity.
	const extra = { custom_rejection_reason: reason }
	document.setValue.submit(
		{ [approvalField.value]: "Rejected", ...extra },
		{
			onSuccess() {
				rejectInFlight.value = false
				showRejectDialog.value = false
				modalController.dismiss()
				toast({
					title: __("Success"),
					text: __("Rejected successfully!"),
					icon: "check-circle",
					position: "bottom-center",
					iconClasses: "text-green-500",
				})
			},
			onError(err) {
				rejectInFlight.value = false
				showErrorFromException(err, __("Rejection failed!"))
			},
		}
	)
}

const cancelMethods = {
	"Leave Application": "myhr.api.cancel_leave_application",
	"Attendance Request": "myhr.api.cancel_attendance_request",
}
const cancelResource = createResource({
	url: cancelMethods[props.modelValue.doctype] || "myhr.api.cancel_leave_application",
	onSuccess() {
		cancelInFlight.value = false
		showCancelDialog.value = false
		modalController.dismiss()
		toast({
			title: __("Success"),
			text: __("Request cancelled."),
			icon: "check-circle",
			position: "bottom-center",
			iconClasses: "text-green-500",
		})
	},
	onError(err) {
		cancelInFlight.value = false
		showErrorFromException(err, __("Cancellation failed!"))
	},
})

function openCancelDialog() {
	cancelReason.value = ""
	cancelReasonError.value = ""
	showCancelDialog.value = true
}

function confirmCancel() {
	const reason = (cancelReason.value || "").trim()
	if (!reason) {
		cancelReasonError.value = __("Cancellation reason is required.")
		return
	}
	cancelReasonError.value = ""
	cancelInFlight.value = true
	cancelResource.submit({
		name: props.modelValue.name,
		reason,
	})
}

const openFormView = () => {
	modalController.dismiss()
	router.push({
		name: `${props.modelValue.doctype.replace(/\s+/g, "")}DetailView`,
		params: { id: props.modelValue.name },
	})
}

onMounted(() => {
	workflow.value = useWorkflow(props.modelValue.doctype)
})
</script>

<style scoped>
ion-modal {
	--height: 100%;
}
</style>
