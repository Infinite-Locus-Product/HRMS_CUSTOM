<template>
	<ion-tab-bar
		slot="bottom"
		class="bg-white/95 backdrop-blur-md border-t border-gray-100 w-full sm:max-w-4xl mx-auto py-1.5 pb-1.5 standalone:pb-safe-bottom"
	>
		<ion-tab-button
			v-for="item in tabItems"
			:key="item.title"
			:tab="item.tab"
			v-bind="item.fullNav ? {} : { href: item.route }"
			:class="[
				'relative bg-transparent text-[10px] tracking-wide transition-all active:scale-95',
				isActiveTab(item)
					? 'text-blue-700 font-black'
					: 'text-gray-500 font-bold hover:text-gray-700',
			]"
			@click="item.fullNav ? fullNavigate(item.route) : undefined"
		>
			<!-- Active pill background behind icon -->
			<div
				class="flex items-center justify-center h-9 w-9 rounded-xl transition-all"
				:class="
					isActiveTab(item)
						? 'bg-blue-50 text-blue-700'
						: 'text-gray-500'
				"
			>
				<component :is="item.icon" class="h-5 w-5" />
			</div>
			<div class="mt-0.5">{{ item.title }}</div>
		</ion-tab-button>
	</ion-tab-bar>
</template>

<script setup>
import { useRoute } from "vue-router"
import { IonTabBar, IonTabButton } from "@ionic/vue"

import HomeIcon from "@/components/icons/HomeIcon.vue"
import LeaveIcon from "@/components/icons/LeaveIcon.vue"
import ExpenseIcon from "@/components/icons/ExpenseIcon.vue"
import AttendanceIcon from "@/components/icons/AttendanceIcon.vue"
import SalaryIcon from "@/components/icons/SalaryIcon.vue"
import { inject } from "vue"

const __ = inject("$translate")
const route = useRoute()

function fullNavigate(path) {
	window.location.href = "/hrms" + path
}

const TAB_SECTION_PREFIXES = {
	Attendance: [
		"/attendance-requests",
		"/shift-requests",
		"/shift-assignments",
		"/employee-checkins",
	],
	Leaves: ["/leave-applications"],
	Expenses: ["/expense-claims", "/employee-advances"],
}

function isActiveTab(item) {
	if (route.path === item.route) return true
	const prefixes = TAB_SECTION_PREFIXES[item.tab] || []
	return prefixes.some((p) => route.path.startsWith(p))
}

const tabItems = [
	{
		icon: HomeIcon,
		title: __("Home"),
		tab: "Home",
		route: "/home",
		fullNav: false,
	},
	{
		icon: AttendanceIcon,
		title: __("Attendance"),
		tab: "Attendance",
		route: "/dashboard/attendance",
		fullNav: false,
	},
	{
		icon: LeaveIcon,
		title: __("Leaves"),
		tab: "Leaves",
		route: "/dashboard/leaves",
		fullNav: false,
	},
	{
		icon: ExpenseIcon,
		title: __("Expenses"),
		tab: "Expenses",
		route: "/dashboard/expense-claims",
		fullNav: false,
	},
	{
		icon: SalaryIcon,
		title: __("Salary"),
		tab: "Salary",
		route: "/dashboard/salary-slips",
		fullNav: false,
	},
]
</script>
