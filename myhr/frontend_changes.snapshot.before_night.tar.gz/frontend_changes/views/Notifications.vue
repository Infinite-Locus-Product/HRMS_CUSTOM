<template>
	<ion-page>
		<ion-content class="ion-padding">
			<div class="flex flex-col h-screen w-screen">
				<div class="w-full sm:max-w-4xl w-full sm:mx-auto">
					<header
						class="flex flex-row bg-white shadow-sm py-4 px-3 items-center justify-between border-b sticky top-0 z-10"
					>
						<div class="flex flex-row items-center">
							<Button
								variant="ghost"
								class="!pl-0 hover:bg-white"
								@click="router.back()"
							>
								<FeatherIcon name="chevron-left" class="h-5 w-5" />
							</Button>
							<h2 class="text-xl font-semibold text-gray-900">{{ __("Notifications") }} </h2>
						</div>
					</header>

					<div class="flex flex-col gap-4 mt-5 p-4">
						<div class="flex flex-row justify-between items-center">
							<div
								class="text-lg text-gray-800 font-semibold"
								v-if="unreadNotificationsCount.data"
							>
								{{ __("{0} Unread", [unreadNotificationsCount.data]) }}
							</div>
							<div class="flex ml-auto gap-1">
								<Button
									v-if="allowPushNotifications"
									variant="outline"
									@click="router.push({ name: 'Settings' })"
								>
									<template #prefix>
										<FeatherIcon name="settings" class="w-4" />
									</template>
									{{ __("Settings") }}
								</Button>
								<Button
									v-if="unreadNotificationsCount.data"
									variant="outline"
									@click="markAllAsRead.submit"
									:loading="markAllAsRead.loading"
								>
									<template #prefix>
										<FeatherIcon name="check-circle" class="w-4" />
									</template>
									{{ __("Mark all as read") }}
								</Button>
								<Button
									v-if="notifications.data?.length"
									variant="outline"
									theme="red"
									@click="confirmClearAll"
									:loading="clearAll.loading"
								>
									<template #prefix>
										<FeatherIcon name="trash-2" class="w-4" />
									</template>
									{{ __("Clear all") }}
								</Button>
							</div>
						</div>

						<div
							class="flex flex-col bg-white rounded divide-y"
							v-if="notifications.data?.length"
						>
							<div
								:class="[
									'flex flex-row items-start gap-3 p-4 border-b last:border-b-0 before:mt-3',
									`before:content-[''] before:shrink-0 before:w-1.5 before:h-1.5 before:rounded-full`,
									item.read ? 'before:bg-transparent' : 'before:bg-blue-500',
								]"
								v-for="item in notifications.data"
								:key="item.name"
							>
								<div
									class="flex flex-row items-start grow cursor-pointer min-w-0"
									@click="openNotification(item)"
								>
									<EmployeeAvatar :userID="item.from_user" size="lg" />
									<div class="flex flex-col gap-0.5 grow ml-3 min-w-0">
										<div
											class="text-sm leading-5 font-normal text-gray-800 break-words"
											v-html="item.message"
										></div>
										<div class="text-xs font-normal text-gray-500">
											{{ dayjs(item.creation).fromNow() }}
										</div>
									</div>
								</div>
								<div class="flex flex-row items-center gap-1 shrink-0 ml-2">
									<Button
										v-if="!item.read"
										variant="ghost"
										size="sm"
										:title="__('Mark as read')"
										@click.stop="markAsRead(item.name)"
									>
										<FeatherIcon name="check" class="w-4 h-4 text-green-600" />
									</Button>
									<Button
										variant="ghost"
										size="sm"
										:title="__('Dismiss')"
										@click.stop="dismissOne(item.name)"
									>
										<FeatherIcon name="x" class="w-4 h-4 text-red-500" />
									</Button>
								</div>
							</div>

						</div>
						<div v-if="notifications.data?.length && notifications.hasNextPage" class="flex">
							<Button
								variant="outline"
								class="ml-auto"
								@click="loadMore"
							>
								{{ __('Load more') }}
							</Button>
						</div>
						<EmptyState v-else-if="!notifications.data" :message="__('You have no notifications')" />
					</div>
				</div>
			</div>
		</ion-content>
	</ion-page>
</template>

<script setup>
import { IonContent, IonPage } from "@ionic/vue"
import { useRouter } from "vue-router"
import { createResource, FeatherIcon, toast } from "frappe-ui"
import { showErrorFromException } from "@/data/errorModal"

import { computed, inject, onMounted, ref } from "vue"
import EmployeeAvatar from "@/components/EmployeeAvatar.vue"
import EmptyState from "@/components/EmptyState.vue"

import {
	unreadNotificationsCount,
	notifications,
	arePushNotificationsEnabled,
} from "@/data/notifications"

const dayjs = inject("$dayjs")
const router = useRouter()
const __ = inject("$translate")
const currentStart = ref(0)
const pageLength = 10


const allowPushNotifications = computed(
	() =>
		window.frappe?.boot.push_relay_server_url &&
		arePushNotificationsEnabled.data
)

const markAllAsRead = createResource({
	url: "hrms.api.mark_all_notifications_as_read",
	onSuccess() {
		notifications.reload()
		unreadNotificationsCount.reload()
	},
})

const clearAll = createResource({
	url: "myhr.api.clear_all_notifications",
	onSuccess() {
		notifications.reload()
		unreadNotificationsCount.reload()
		toast({
			title: __("Cleared"),
			text: __("All notifications removed."),
			icon: "check-circle",
			position: "bottom-center",
			iconClasses: "text-green-500",
		})
	},
	onError(err) {
		showErrorFromException(err, __("Could not clear notifications"))
	},
})

function confirmClearAll() {
	if (!notifications.data?.length) return
	if (window.confirm(__("Clear all notifications? This cannot be undone."))) {
		clearAll.submit()
	}
}

// Mark-as-read goes through a server endpoint because the Employee role only
// has read perm on PWA Notification — `frappe.client.set_value` would 403.
const markReadResource = createResource({
	url: "myhr.api.mark_notification_read",
	onSuccess() {
		notifications.reload()
		unreadNotificationsCount.reload()
	},
	onError(err) {
		showErrorFromException(err, __("Could not mark as read"))
	},
})

function markAsRead(name) {
	markReadResource.submit({ notification: name })
}

const dismissOneResource = createResource({
	url: "myhr.api.dismiss_notification",
	onSuccess() {
		notifications.reload()
		unreadNotificationsCount.reload()
	},
	onError(err) {
		showErrorFromException(err, __("Could not dismiss notification"))
	},
})

function dismissOne(name) {
	dismissOneResource.submit({ notification: name })
}

// Map reference_document_type → existing PWA route. Anything not in this map
// stays on /notifications (keeps the row visible instead of throwing on an
// unregistered route name, which silently bails the v-for render).
const REFERENCE_TYPE_ROUTES = {
	"Leave Application": "LeavesDashboard",
	"Expense Claim": "ExpenseClaimsDashboard",
	"Attendance Request": "AttendanceDashboard",
	"Policy Acknowledgement": "EmployeePolicies",
	"HR Policy": "EmployeePolicies",
}

function openNotification(item) {
	if (!item.read) markAsRead(item.name)
	const target = REFERENCE_TYPE_ROUTES[item.reference_document_type]
	if (target) {
		router.push({ name: target })
	}
}

onMounted(() => {
	// Show only unread. Read items disappear from the PWA list — that's the
	// "mark-as-read removes it from view" model the user expects, and it lets
	// Mark-all-as-read empty the list without deleting rows.
	notifications.filters = {
		...(notifications.filters || {}),
		read: 0,
	}
	notifications.start = 0
	notifications.pageLength = 10
	notifications.reload()
})

function loadMore() {
	currentStart.value += pageLength
	notifications.start = currentStart.value
	notifications.pageLength = pageLength
	notifications.list.fetch()
}
</script>
