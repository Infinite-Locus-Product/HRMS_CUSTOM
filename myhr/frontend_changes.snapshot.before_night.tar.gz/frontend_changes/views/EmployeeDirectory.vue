<template>
	<ion-page>
		<ion-content class="ion-no-padding">
			<div class="flex flex-col h-full w-full bg-gray-50 overflow-y-auto">
				<div class="w-full min-h-full sm:max-w-4xl mx-auto bg-white flex flex-col shadow-sm border-x border-gray-100 relative">
					<!-- Header matching BaseLayout style -->
					<div class="flex flex-col bg-white shadow-sm p-4 sticky top-0 z-10 border-b border-gray-100">
						<div class="flex flex-row justify-between items-center">
							<div class="flex flex-row items-center gap-2">
								<Button
									variant="ghost"
									class="!pl-0 hover:bg-white mr-2"
									@click="goBack()"
								>
									<FeatherIcon name="chevron-left" class="h-5 w-5" />
								</Button>
								<h2 class="text-xl font-bold text-gray-900">
									{{ __("Employee Directory") }}
								</h2>
							</div>
							<div class="flex flex-row items-center gap-3 ml-auto">
								<router-link
									:to="{ name: 'Notifications' }"
									v-slot="{ navigate }"
									class="flex flex-col items-center"
								>
									<span class="relative inline-block" @click="navigate">
										<FeatherIcon name="bell" class="h-6 w-6" />
										<span
											v-if="unreadNotificationsCount.data"
											class="absolute top-0 right-0.5 inline-block w-2 h-2 bg-red-600 rounded-full border border-white"
										>
										</span>
									</span>
								</router-link>
								<router-link
									:to="{ name: 'Profile' }"
									class="flex flex-col items-center"
								>
									<Avatar
										:image="user.data.user_image"
										:label="user.data.first_name"
										size="xl"
									/>
								</router-link>
							</div>
						</div>
					</div>

					<!-- Content -->
					<div class="flex-1 overflow-y-auto p-4 space-y-4">
						<!-- Search Bar -->
						<div class="relative">
				<FeatherIcon
					name="search"
					class="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400"
				/>
				<input
					v-model="searchQuery"
					type="text"
					:placeholder="__('Search by name, role, dept, phone, email...')"
					class="w-full pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-300 focus:border-transparent shadow-sm transition-all"
				/>
			</div>

			<!-- Department filter chips — single-select; "All" resets. Hidden if 0 or 1 distinct department. -->
			<div v-if="distinctDepartments.length > 1" class="flex gap-2 overflow-x-auto pb-1 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide">
				<button
					type="button"
					class="shrink-0 px-3 h-8 rounded-full text-xs font-bold border whitespace-nowrap transition-all"
					:class="selectedDepartment === null
						? 'bg-gray-900 text-white border-gray-900'
						: 'bg-white text-gray-700 border-gray-200 hover:border-gray-400'"
					@click="selectedDepartment = null"
				>
					{{ __("All") }} ({{ employees.length }})
				</button>
				<button
					v-for="dept in distinctDepartments"
					:key="dept"
					type="button"
					class="shrink-0 px-3 h-8 rounded-full text-xs font-medium border whitespace-nowrap transition-all"
					:class="selectedDepartment === dept
						? 'bg-indigo-50 text-indigo-700 border-indigo-300'
						: 'bg-white text-gray-700 border-gray-200 hover:border-gray-400'"
					@click="selectedDepartment = (selectedDepartment === dept ? null : dept)"
				>
					{{ dept }} ({{ departmentCounts[dept] || 0 }})
				</button>
			</div>

			<!-- Directory List -->
			<div v-if="filteredEmployees.length" class="flex flex-col bg-white rounded-lg shadow-sm border border-gray-100">
				<div
					v-for="(emp, index) in filteredEmployees"
					:key="emp.employee_id"
					class="flex flex-col"
					:class="{ 'border-b border-gray-100': index !== filteredEmployees.length - 1 }"
				>
					<button
						type="button"
						class="flex flex-row items-center p-4 gap-3 w-full text-left hover:bg-gray-50/80 transition-colors rounded-none"
						@click="toggleExpand(emp.employee_id)"
					>
						<Avatar
							:image="emp.image"
							:label="emp.employee_name"
							size="xl"
						/>
						<div class="flex flex-col flex-grow min-w-0 ml-1">
							<div class="text-base font-semibold text-gray-900 truncate">
								{{ emp.employee_name }}
							</div>
							<div
								v-if="emp.designation"
								class="text-sm font-normal text-gray-500 truncate mt-0.5"
							>
								{{ emp.designation }}
							</div>
						</div>
						<FeatherIcon
							:name="isExpanded(emp.employee_id) ? 'chevron-up' : 'chevron-down'"
							class="h-5 w-5 text-gray-400 shrink-0"
						/>
					</button>
					<div
						v-show="isExpanded(emp.employee_id)"
						class="px-4 pb-4 pt-0 pl-[4.25rem] sm:pl-4 border-t border-gray-50 bg-gray-50/40"
					>
						<div v-if="emp.department" class="text-sm text-gray-600 mb-3">
							<span class="text-[10px] font-bold uppercase tracking-wider text-gray-400 block mb-0.5">{{ __("Department") }}</span>
							{{ emp.department }}
						</div>
						<div class="flex flex-col gap-2 w-full max-w-sm">
							<a
								v-if="emp.mobile_number"
								:href="'tel:' + emp.mobile_number"
								class="inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-gray-200 bg-white text-gray-800 hover:bg-gray-50 transition-colors text-sm"
								@click.stop
							>
								<FeatherIcon name="phone" class="h-4 w-4 text-gray-500 shrink-0" />
								<span class="truncate">{{ emp.mobile_number }}</span>
							</a>
							<a
								v-if="emp.employee_email"
								:href="'mailto:' + emp.employee_email"
								class="inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-gray-200 bg-white text-gray-800 hover:bg-gray-50 transition-colors text-sm"
								@click.stop
							>
								<FeatherIcon name="mail" class="h-4 w-4 text-gray-500 shrink-0" />
								<span class="truncate break-all">{{ emp.employee_email }}</span>
							</a>
						</div>
					</div>
				</div>
			</div>

			<!-- Empty State -->
			<div v-else-if="!loading" class="flex flex-col items-center justify-center py-20 opacity-50">
				<FeatherIcon name="users" class="h-16 w-16 mb-4 text-gray-400" />
				<p class="text-gray-500 font-medium tracking-tight">
					{{ searchQuery || selectedDepartment ? __("No matching employees") : __("Directory is empty") }}
				</p>
				<button
					v-if="searchQuery || selectedDepartment"
					type="button"
					class="mt-3 text-xs font-bold text-indigo-600 hover:text-indigo-700"
					@click="searchQuery = ''; selectedDepartment = null"
				>
					{{ __("Clear filters") }}
				</button>
			</div>

			<!-- Loading State -->
			<div v-if="loading" class="flex justify-center py-20">
				<LoadingIndicator />
			</div>
			</div>
			</div>
			</div>
		</ion-content>
	</ion-page>
</template>

<script setup>
import { ref, computed, inject } from "vue"
import { FeatherIcon, Avatar, LoadingIndicator, createResource } from "frappe-ui"
import { useIonRouter, onIonViewWillEnter } from "@ionic/vue"
import { unreadNotificationsCount } from "@/data/notifications"
import { showErrorFromException } from "@/data/errorModal"

const ionRouter = useIonRouter()
const user = inject("$user")
const __ = inject("$translate")

function goBack() {
	// Fall back to Home if there's no real history (PWA deep link / SW cached entry).
	if (window.history.length > 2) {
		window.history.back()
	} else {
		ionRouter.push({ name: "Home" })
	}
}

const employees = ref([])
const searchQuery = ref("")
const selectedDepartment = ref(null)
const loading = ref(true)

const expandedIds = ref(new Set())

function isExpanded(employeeId) {
	return expandedIds.value.has(employeeId)
}

function toggleExpand(employeeId) {
	const next = new Set(expandedIds.value)
	if (next.has(employeeId)) {
		next.delete(employeeId)
	} else {
		next.add(employeeId)
	}
	expandedIds.value = next
}

const dirResource = createResource({
	url: "myhr.api.get_employee_directory",
	auto: true,
	onSuccess: (data) => {
		employees.value = data || []
		loading.value = false
	},
	onError: (err) => {
		console.error("Directory fetch failed:", err)
		loading.value = false
		showErrorFromException(err, __("Could not load directory"))
	}
})

// Refresh on re-entry so newly-added / departed colleagues appear without a manual refresh.
onIonViewWillEnter(() => {
	dirResource.reload()
})

/** Distinct, alphabetised list of departments — populates the filter chips. */
const distinctDepartments = computed(() => {
	const set = new Set()
	for (const e of employees.value) {
		if (e.department) set.add(e.department)
	}
	return Array.from(set).sort()
})

/** Per-department head-count for the chip labels — computed once per data load. */
const departmentCounts = computed(() => {
	const counts = {}
	for (const e of employees.value) {
		if (!e.department) continue
		counts[e.department] = (counts[e.department] || 0) + 1
	}
	return counts
})

/** Combines department chip + free-text search. Search corpus extended to phone + email. */
const filteredEmployees = computed(() => {
	let list = employees.value
	if (selectedDepartment.value) {
		list = list.filter((e) => e.department === selectedDepartment.value)
	}
	if (!searchQuery.value) return list
	const q = searchQuery.value.toLowerCase().trim()
	return list.filter(
		(e) =>
			(e.employee_name && e.employee_name.toLowerCase().includes(q)) ||
			(e.designation && e.designation.toLowerCase().includes(q)) ||
			(e.department && e.department.toLowerCase().includes(q)) ||
			(e.employee_id && e.employee_id.toLowerCase().includes(q)) ||
			(e.mobile_number && String(e.mobile_number).toLowerCase().includes(q)) ||
			(e.employee_email && e.employee_email.toLowerCase().includes(q))
	)
})
</script>
